# Weather Logger

Ten program ma za zadanie dodawać do pliku json aktualną pogodę z wybranej stacji (domyślnie gorzów wlkp)
Po kilku dniach uruchamiania będziemy mieli już ciekawą historię jaka była  pogoda.

# instalacja zależności

```
pip install -r requirements.txt
```

# uruchomienie
python main.py

## pochodzenie danych

info o danych tutaj: https://danepubliczne.imgw.pl/apiinfo