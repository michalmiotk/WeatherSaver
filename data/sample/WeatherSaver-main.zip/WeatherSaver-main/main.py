from user_api import UserApi

user_api = UserApi()
user_api.new_log()